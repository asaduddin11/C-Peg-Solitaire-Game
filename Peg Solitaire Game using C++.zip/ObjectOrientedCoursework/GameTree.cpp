
#include "GameTree.h"
#include "GameBoard.h"

namespace play
{
	using namespace board;

	GameTree::GameTree(GameBoard *gb)
	{
		this->gb = gb;
	}

	void GameTree::addChild(GameTree *child)
	{
		children.push_back(child);
	}

	GameBoard *GameTree::getGameBoard()
	{
		return gb;
	}

	bool GameTree::hasChildren()
	{
		return children.size() > 0;
	}

	GameTree *GameTree::getFirstChild()
	{
		return children[0];
	}

	void GameTree::removeFirstChild()
	{
		children.erase(children.begin());
	}

	int GameTree::numChildren()
	{
		return children.size();
	}
}
