
#include "Position.h"

namespace board
{

	Position::Position(int row, int col)
	{
		this->row = row;
		this->col = col;
	}

	int Position::getRow()
	{
		return row;
	}

	int Position::getCol()
	{
		return col;
	}

	std::wstring Position::toString()
	{
		return L"[" + std::to_string(row) + L"," + std::to_string(col) + L"]";
	}

	int Position::hashCode()
	{
		int result = 17;

		result = 37*result + row;
		result = 37*result + col;

		return result;
	}

	bool Position::equals(void *other)
	{
		if (!(dynamic_cast<Position*>(other) != nullptr))
		{
			return false;
		}
		Position *that = static_cast<Position*>(other);

		if (this->row != that->row)
		{
			return false;
		}

		return this->col == that->col;
	}
}
