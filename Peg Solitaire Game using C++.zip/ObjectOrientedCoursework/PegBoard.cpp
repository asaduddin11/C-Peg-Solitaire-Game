
#include "PegBoard.h"
#include "Play.h"

namespace main
{
	using namespace play;

	void PegBoard::main(std::vector<std::wstring> &args)
	{

	Play *play = new Play(args);

	play->DFS();
	}
}
