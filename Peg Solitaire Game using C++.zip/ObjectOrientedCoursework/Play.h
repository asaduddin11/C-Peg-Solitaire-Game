#pragma once
#include <string>
#include <vector>
#include <iostream>

namespace board { class GameBoard; }
namespace play { class GameTree; }


namespace play
{

	using namespace board;

	class Play
	{

	public:
		GameBoard *startBoard;


		virtual ~Play()
		{
			delete startBoard;
		}

		Play(std::vector<std::wstring> &args);


	private:
		void init(int row, int col);

		public:
		virtual void DFS();

		private:
		void printWinningGame(GameTree *parent);

		bool play(GameBoard *gb, GameTree *parent);
	};

}
