#include "GameBoard.h"
#include "Position.h"
#include "Move.h"
#include "Moves.h"

namespace board
{

	GameBoard::GameBoard(int row, int col)
	{
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				pins[i][j] = true;
			}
		}
		pins[row][col] = false;
	}

	GameBoard::GameBoard(int board)
	{
		for (int i = 4; i >= 0; --i)
		{
			for (int j = i; j >= 0; --j)
			{
				if ((board & 1) == 1)
				{
					pins[i][j] = true;
				}
				else
				{
					pins[i][j] = false;
				}
				board /= 2;
			}
		}

	}

	GameBoard::GameBoard(const GameBoard &that)
	{
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				pins[i][j] = that->pins[i][j];
			}
		}
	}

	std::vector<GameBoard*> GameBoard::possibleBoards()
	{
		std::vector<GameBoard*> boards;

		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				Position *start = new Position(i,j);
				std::vector<Move*> possibleMoves = Moves::getMoves(start);
				for (auto move : possibleMoves)
				{
					if (validMove(move))
					{
						boards.push_back(jump(move));
					}
				}
			}
		}

		return boards;
	}

	bool GameBoard::validMove(Move *move)
	{
		if (!pins[move->getStart()->getRow()][move->getStart()->getCol()]) // empty start
		{
			return false;
		}
		if (!pins[move->getJump()->getRow()][move->getJump()->getCol()]) // empty jump over
		{
			return false;
		}
		if (pins[move->getEnd()->getRow()][move->getEnd()->getCol()]) // filled in end
		{
			return false;
		}

		return true;
	}

	GameBoard *GameBoard::jump(Move *move)
	{
		GameBoard *gb = new GameBoard(this);

		gb->pins[move->getStart()->getRow()][move->getStart()->getCol()] = false;
		gb->pins[move->getJump()->getRow()][move->getJump()->getCol()] = false;
		gb->pins[move->getEnd()->getRow()][move->getEnd()->getCol()] = true;

		return gb;
	}

	bool GameBoard::finalBoard()
	{
		int remainingPins = 0;

		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				if (pins[i][j])
				{
					remainingPins++;
					if (remainingPins > 1) // optimize, early out, more than 1 pin is not final board
					{
						return false;
					}
				}
			}
		}

		return remainingPins == 1;
	}

	int GameBoard::toInt()
	{
		int ret = 0;
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				ret *= 2;
				if (pins[i][j])
				{
					ret |= 1;
				}
			}
		}

		return ret;
	}

	std::wstring GameBoard::toString()
	{
		StringBuilder *sb = new StringBuilder();

		for (int i = 0; i < 5; ++i)
		{
			for (int s = 4 - i; s > 0; --s)
			{
				sb->append(L" ");
			}
			for (int j = 0; j <= i; ++j)
			{
				sb->append(pins[i][j] ? L'X' : L'O')->append(L" ");
			}
			sb->append(L"\n");
		}
		//		sb.append(toInt()+ "\n");

		return sb->toString();
	}
}
