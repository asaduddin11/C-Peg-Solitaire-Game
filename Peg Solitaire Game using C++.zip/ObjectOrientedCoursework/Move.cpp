
#include "Move.h"
#include "Position.h"

namespace board
{

	Move::Move(Position *start, Position *jump, Position *end)
	{
		this->start = start;
		this->jump = jump;
		this->end = end;
	}

	Position *Move::getStart()
	{
		return start;
	}

	Position *Move::getJump()
	{
		return jump;
	}

	Position *Move::getEnd()
	{
		return end;
	}

	std::wstring Move::toString()
	{
		StringBuilder *sb = new StringBuilder();

		sb->append(L"{" + start);
		sb->append(L"," + jump);
		sb->append(L"," + end + L"}");

		return sb->toString();
	}
}
