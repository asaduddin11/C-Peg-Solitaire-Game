
#include "Play.h"
#include "GameBoard.h"
#include "GameTree.h"

namespace play
{
	using namespace board;

	Play::Play(std::vector<std::wstring> &args) throw(IOException)
	{
		if (args.empty())
		{
	//		init(0, 0); 	} else {
					// //
		int n1, n2;
				InputStreamReader tempVar(System::in);
				BufferedReader *stdin = new BufferedReader(&tempVar);
						std::wcout << L"Name: Asha " << std::endl;


						std::wcout << L"......................................" << std::endl;
			std::wcout << L"Enter the position of the hole:" << std::endl;

			n1 = static_cast<Integer>(stdin->readLine());
			n2 = static_cast<Integer>(stdin->readLine());
					init(n1,n2);
		}
		 else
		 {
	 init(std::stoi(args[0]),std::stoi(args[1]));
		 }
	}

	void Play::init(int row, int col)
	{
		startBoard = new GameBoard(row, col);
	}

	void Play::DFS()
	{
		GameTree *root = new GameTree(startBoard);

		for (auto nextBoard : startBoard->possibleBoards())
		{
			GameTree *nextNode = new GameTree(nextBoard);
			if (play(nextBoard, nextNode))
			{
				root->addChild(nextNode);
			}
		}

				printWinningGame(root);

				//crazy loop
		//		while (root.hasChildren())
		//                {
		//			printWinningGame(root);	
		//		}
	}

	void Play::printWinningGame(GameTree *parent)
	{
		std::wcout << parent->getGameBoard() << std::endl;

		if (parent->numChildren() > 0)
		{
			GameTree *nextNode = parent->getFirstChild();
			printWinningGame(nextNode); // recurse
			if (nextNode->numChildren() == 0)
			{
				parent->removeFirstChild();
			}
		}
		else
		{
			std::wcout << L"===============================================" << std::endl;
		}
	}

	bool Play::play(GameBoard *gb, GameTree *parent)
	{

		if (gb->finalBoard()) // remember this path was a winning path
		{
			return true;
		}

		std::vector<GameBoard*> nextBoards = gb->possibleBoards();

		bool found = false;

		for (auto nextBoard : nextBoards)
		{
			GameTree *nextNode = new GameTree(nextBoard);
			if (play(nextBoard, nextNode))
			{ // recurse
				found = true;
				parent->addChild(nextNode);
			}
		}

		return found;
	}
}
