
#include "Moves.h"
#include "Move.h"
#include "Position.h"

namespace board
{

std::unordered_map<Position*, std::vector<Move*>> Moves::validMoves;

	Moves::StaticConstructor::StaticConstructor()
	{
	/* 
	 *          0,0 
	 *       1,0  1,1
	 *     2,0  2,1  2,2
	 *   3,0  3,1  3,2  3,3
	 * 4,0  4,1  4,2  4,3  4,4
	 * 
	 */
	Position *start;
            
	start = new Position(0,0);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar(start, new Position(1,0), new Position(2,0));
	validMoves[start].push_back(&tempVar);
	Move tempVar2(start, new Position(1,1), new Position(2,2));
	validMoves[start].push_back(&tempVar2);
            
	start = new Position(1,0);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar3(start, new Position(2,0), new Position(3,0));
	validMoves[start].push_back(&tempVar3);
	Move tempVar4(start, new Position(2,1), new Position(3,2));
	validMoves[start].push_back(&tempVar4);
            
	start = new Position(1,1);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar5(start, new Position(2,1), new Position(3,1));
	validMoves[start].push_back(&tempVar5);
	Move tempVar6(start, new Position(2,2), new Position(3,3));
	validMoves[start].push_back(&tempVar6);
	/* 
	 *          0,0 
	 *       1,0  1,1
	 *     2,0  2,1  2,2
	 *   3,0  3,1  3,2  3,3
	 * 4,0  4,1  4,2  4,3  4,4
	 * 
	 */	
	start = new Position(2,0);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar7(start, new Position(1,0), new Position(0,0));
	validMoves[start].push_back(&tempVar7);
	Move tempVar8(start, new Position(2,1), new Position(2,2));
	validMoves[start].push_back(&tempVar8);
	Move tempVar9(start, new Position(3,0), new Position(4,0));
	validMoves[start].push_back(&tempVar9);
	Move tempVar10(start, new Position(3,1), new Position(4,2));
	validMoves[start].push_back(&tempVar10);
            
	start = new Position(2,1);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar11(start, new Position(3,1), new Position(4,1));
	validMoves[start].push_back(&tempVar11);
	Move tempVar12(start, new Position(3,2), new Position(4,3));
	validMoves[start].push_back(&tempVar12);
            
	start = new Position(2,2);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar13(start, new Position(1,1), new Position(0,0));
	validMoves[start].push_back(&tempVar13);
	Move tempVar14(start, new Position(2,1), new Position(2,0));
	validMoves[start].push_back(&tempVar14);
	Move tempVar15(start, new Position(3,2), new Position(4,2));
	validMoves[start].push_back(&tempVar15);
	Move tempVar16(start, new Position(3,3), new Position(4,4));
	validMoves[start].push_back(&tempVar16);
	/* 
	 *          0,0 
	 *       1,0  1,1
	 *     2,0  2,1  2,2
	 *   3,0  3,1  3,2  3,3
	 * 4,0  4,1  4,2  4,3  4,4
	 * 
	 */	
	start = new Position(3,0);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar17(start, new Position(2,0), new Position(1,0));
	validMoves[start].push_back(&tempVar17);
	Move tempVar18(start, new Position(3,1), new Position(3,2));
	validMoves[start].push_back(&tempVar18);
            
	start = new Position(3,1);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar19(start, new Position(2,1), new Position(1,1));
	validMoves[start].push_back(&tempVar19);
	Move tempVar20(start, new Position(3,2), new Position(3,3));
	validMoves[start].push_back(&tempVar20);
            
	start = new Position(3,2);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar21(start, new Position(2,1), new Position(1,0));
	validMoves[start].push_back(&tempVar21);
	Move tempVar22(start, new Position(3,1), new Position(3,0));
	validMoves[start].push_back(&tempVar22);
            
	start = new Position(3,3);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar23(start, new Position(2,2), new Position(1,1));
	validMoves[start].push_back(&tempVar23);
	Move tempVar24(start, new Position(3,2), new Position(3,1));
	validMoves[start].push_back(&tempVar24);
	/* 
	 *          0,0 
	 *       1,0  1,1
	 *     2,0  2,1  2,2
	 *   3,0  3,1  3,2  3,3
	 * 4,0  4,1  4,2  4,3  4,4
	 * 
	 */	
	start = new Position(4,0);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar25(start, new Position(3,0), new Position(2,0));
	validMoves[start].push_back(&tempVar25);
	Move tempVar26(start, new Position(4,1), new Position(4,2));
	validMoves[start].push_back(&tempVar26);
            
	start = new Position(4,1);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar27(start, new Position(3,1), new Position(2,1));
	validMoves[start].push_back(&tempVar27);
	Move tempVar28(start, new Position(4,2), new Position(4,3));
	validMoves[start].push_back(&tempVar28);
            
	start = new Position(4,2);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar29(start, new Position(3,1), new Position(2,0));
	validMoves[start].push_back(&tempVar29);
	Move tempVar30(start, new Position(3,2), new Position(2,2));
	validMoves[start].push_back(&tempVar30);
	Move tempVar31(start, new Position(4,1), new Position(4,0));
	validMoves[start].push_back(&tempVar31);
	Move tempVar32(start, new Position(4,3), new Position(4,4));
	validMoves[start].push_back(&tempVar32);
            
	start = new Position(4,3);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar33(start, new Position(3,2), new Position(2,1));
	validMoves[start].push_back(&tempVar33);
	Move tempVar34(start, new Position(4,2), new Position(4,1));
	validMoves[start].push_back(&tempVar34);
            
	start = new Position(4,4);
	validMoves.emplace(start, std::vector<Move*>());
	Move tempVar35(start, new Position(3,3), new Position(2,2));
	validMoves[start].push_back(&tempVar35);
	Move tempVar36(start, new Position(4,3), new Position(4,2));
	validMoves[start].push_back(&tempVar36);
	}

Moves::StaticConstructor Moves::staticConstructor;

	std::vector<Move*> Moves::getMoves(Position *position)
	{
		if (validMoves.find(position) == validMoves.end())
		{
			throw std::exception();
		}

		return validMoves[position];
	}

	std::wstring Moves::toString()
	{
		return validMoves.toString();
	}
}
