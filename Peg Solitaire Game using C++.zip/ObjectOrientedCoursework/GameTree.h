#pragma once

#include <vector>
namespace board { class GameBoard; }

namespace play
{


	using namespace board;

	class GameTree
	{
	public:
		GameTree *level;

		GameBoard *gb;
		std::vector<GameTree*> children;

		virtual ~GameTree()
		{
			delete level;
			delete gb;
		}

		GameTree(GameBoard *gb);

		virtual void addChild(GameTree *child);

		virtual GameBoard *getGameBoard();

		virtual bool hasChildren();

		virtual GameTree *getFirstChild();

		virtual void removeFirstChild();

		virtual int numChildren();
	};

}
