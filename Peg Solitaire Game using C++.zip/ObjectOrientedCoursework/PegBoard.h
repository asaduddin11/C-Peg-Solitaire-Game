#pragma once

//========================================================================
// This conversion was produced by the Free Edition of
// Java to C++ Converter courtesy of Tangible Software Solutions.
// Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
//========================================================================

#include <string>
#include <vector>

/*
 /*
 * Name:Asha 
// DFS
 * 
 */
namespace main
{

	using namespace play;


	class PegBoard
	{

	/// <param name="args"> </param>
	static void main(std::vector<std::wstring> &args) throw(IOException);
	};
}
