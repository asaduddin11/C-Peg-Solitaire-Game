#pragma once

#include <string>
#include <unordered_map>
#include <vector>
#include <stdexcept>
namespace board { class Move; }
namespace board { class Position; }

namespace board
{



	class Moves
	{
	private:
		static std::unordered_map<Position*, std::vector<Move*>> validMoves;

		private:
			class StaticConstructor
			{
			public:
				StaticConstructor();
			};

		private:
			static Moves::StaticConstructor staticConstructor;



	public:
		static std::vector<Move*> getMoves(Position *position);


		std::wstring toString() override;
	};

}
