#pragma once


#include <string>
#include <vector>
namespace board { class Move; }

namespace board
{



	class GameBoard
	{

		// board consists of pegs and holes in a 5 x 5, but only uses triangular pyramid
	public:
		bool pins[5][5];

		GameBoard(int row, int col);


		GameBoard(int board);


		// copy constructor
		GameBoard(const GameBoard &that);


		virtual std::vector<GameBoard*> possibleBoards();


		virtual bool validMove(Move *move);


		virtual GameBoard *jump(Move *move);


		virtual bool finalBoard();


		virtual int toInt();


		std::wstring toString();
	};

}
