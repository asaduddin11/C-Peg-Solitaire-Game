#pragma once
#include <string>
#include "stringbuilder.h"

namespace board { class Position; }

namespace board
{


	class Move
	{
	private:
		Position *start;
		Position *jump;
		Position *end;

	public:
		virtual ~Move()
		{
			delete start;
			delete jump;
			delete end;
		}

		Move(Position *start, Position *jump, Position *end);

		virtual Position *getStart();
		virtual Position *getJump();
		virtual Position *getEnd();

		std::wstring toString() override;
	};

}
