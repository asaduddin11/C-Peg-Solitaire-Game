#pragma once

#include <string>

namespace board
{


	class Position
	{
	public:
		int row = 0;
		int col = 0;

		Position(int row, int col);

		virtual int getRow();
		virtual int getCol();

		std::wstring toString();

		int hashCode();

		bool equals(void *other);
	};

}
